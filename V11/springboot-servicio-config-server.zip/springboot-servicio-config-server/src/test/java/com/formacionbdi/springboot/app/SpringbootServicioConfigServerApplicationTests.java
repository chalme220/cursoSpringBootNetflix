package com.formacionbdi.springboot.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
