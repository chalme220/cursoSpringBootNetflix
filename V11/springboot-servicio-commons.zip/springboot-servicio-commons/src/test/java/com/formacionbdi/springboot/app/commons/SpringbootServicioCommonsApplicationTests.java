package com.formacionbdi.springboot.app.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioCommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
